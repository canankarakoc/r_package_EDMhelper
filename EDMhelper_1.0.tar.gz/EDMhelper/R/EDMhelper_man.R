require(rEDM)

data("sardine_anchovy_sst")

segment_data(df$)
